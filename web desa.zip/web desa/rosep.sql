-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Okt 2025 pada 05.22
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rosep`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(3) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$/EQ2gBZ5LuJNcLVi0iD4n.uyzYc2P2xqvcEWV6tGHF6pcL94WfprS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `penulis` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id`, `judul`, `isi`, `gambar`, `tanggal`, `penulis`) VALUES
(2, 'rosep', 'ini rosep', '1758342309_1.png', '2025-09-20', 'Admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `profil_desa`
--

CREATE TABLE `profil_desa` (
  `id` int(11) NOT NULL,
  `visi` varchar(255) NOT NULL,
  `misi` varchar(255) NOT NULL,
  `sejarah` varchar(255) NOT NULL,
  `bagan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `profil_desa`
--

INSERT INTO `profil_desa` (`id`, `visi`, `misi`, `sejarah`, `bagan`) VALUES
(3, 'uang', 'bekerja', 'bisa ayo', '1758343534_2.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_penduduk`
--

CREATE TABLE `t_penduduk` (
  `id` int(11) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kelamin` varchar(1) NOT NULL,
  `usia` int(3) NOT NULL,
  `rt` int(3) NOT NULL,
  `rw` int(3) NOT NULL,
  `dusun` varchar(100) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `agama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_penduduk`
--

INSERT INTO `t_penduduk` (`id`, `no_kk`, `nik`, `nama`, `kelamin`, `usia`, `rt`, `rw`, `dusun`, `pendidikan`, `pekerjaan`, `status`, `agama`) VALUES
(1, '3501012345670001', '3501010101010001', 'Budi Santoso', 'L', 45, 1, 1, 'Krajan', 'SMA', 'Petani', 'Kawin', 'Islam'),
(3, '3501012345670001', '3501010101010003', 'Andi Santoso', 'L', 20, 1, 1, 'Krajan', 'SMA', 'Mahasiswa', 'Belum Kawin', 'Islam'),
(4, '3501012345670001', '3501010101010004', 'Dewi Santoso', 'P', 17, 1, 1, 'Krajan', 'SMA', 'Pelajar', 'Belum Kawin', 'Islam'),
(5, '3501012345670002', '3501010101020001', 'Slamet Riyadi', 'L', 50, 1, 2, 'Krajan', 'SMP', 'Pedagang', 'Kawin', 'Islam'),
(6, '3501012345670002', '3501010101020002', 'Sri Wahyuni', 'P', 48, 1, 2, 'Krajan', 'SMP', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(7, '3501012345670002', '3501010101020003', 'Arif Riyadi', 'L', 22, 1, 2, 'Krajan', 'SMA', 'Karyawan', 'Belum Kawin', 'Islam'),
(8, '3501012345670002', '3501010101020004', 'Nisa Riyadi', 'P', 19, 1, 2, 'Krajan', 'SMA', 'Pelajar', 'Belum Kawin', 'Islam'),
(9, '3501012345670003', '3501010101030001', 'Joko Widodo', 'L', 38, 2, 1, 'Sumber', 'S1', 'PNS', 'Kawin', 'Islam'),
(10, '3501012345670003', '3501010101030002', 'Megawati', 'P', 36, 2, 1, 'Sumber', 'S1', 'Guru', 'Kawin', 'Islam'),
(11, '3501012345670003', '3501010101030003', 'Putra Widodo', 'L', 12, 2, 1, 'Sumber', 'SD', 'Pelajar', 'Belum Kawin', 'Islam'),
(12, '3501012345670004', '3501010101040001', 'Teguh Prasetyo', 'L', 33, 2, 2, 'Sumber', 'SMA', 'Sopir', 'Kawin', 'Islam'),
(13, '3501012345670004', '3501010101040002', 'Ratna Prasetyo', 'P', 30, 2, 2, 'Sumber', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(14, '3501012345670004', '3501010101040003', 'Anisa Prasetyo', 'P', 5, 2, 2, 'Sumber', 'TK', 'Pelajar', 'Belum Kawin', 'Islam'),
(15, '3501012345670005', '3501010101050001', 'Heri Kurniawan', 'L', 28, 3, 1, 'Krajan', 'SMA', 'Karyawan', 'Kawin', 'Islam'),
(16, '3501012345670005', '3501010101050002', 'Lina Kurniawati', 'P', 25, 3, 1, 'Krajan', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(17, '3501012345670005', '3501010101050003', 'Rizky Kurniawan', 'L', 2, 3, 1, 'Krajan', 'PAUD', 'Pelajar', 'Belum Kawin', 'Islam'),
(18, '3501012345670006', '3501010101060001', 'Agus Setiawan', 'L', 40, 3, 2, 'Sumber', 'SMP', 'Petani', 'Kawin', 'Islam'),
(19, '3501012345670006', '3501010101060002', 'Nur Aini', 'P', 38, 3, 2, 'Sumber', 'SMP', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(20, '3501012345670006', '3501010101060003', 'Fajar Setiawan', 'L', 15, 3, 2, 'Sumber', 'SMP', 'Pelajar', 'Belum Kawin', 'Islam'),
(21, '3501012345670007', '3501010101070001', 'Wahyu Hidayat', 'L', 29, 4, 1, 'Krajan', 'SMA', 'Satpam', 'Kawin', 'Islam'),
(22, '3501012345670007', '3501010101070002', 'Dewi Lestari', 'P', 27, 4, 1, 'Krajan', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(23, '3501012345670007', '3501010101070003', 'Nabila Hidayat', 'P', 4, 4, 1, 'Krajan', 'TK', 'Pelajar', 'Belum Kawin', 'Islam'),
(24, '3501012345670008', '3501010101080001', 'Samsul Arifin', 'L', 55, 4, 2, 'Sumber', 'SD', 'Petani', 'Kawin', 'Islam'),
(25, '3501012345670008', '3501010101080002', 'Karsiyem', 'P', 53, 4, 2, 'Sumber', 'SD', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(26, '3501012345670009', '3501010101090001', 'Hendro Saputro', 'L', 31, 5, 1, 'Krajan', 'D3', 'Teknisi', 'Kawin', 'Islam'),
(27, '3501012345670009', '3501010101090002', 'Maya Sari', 'P', 28, 5, 1, 'Krajan', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(28, '3501012345670010', '3501010101100001', 'Tono Hartono', 'L', 47, 5, 2, 'Sumber', 'SMP', 'Buruh', 'Kawin', 'Islam'),
(29, '3501012345670010', '3501010101100002', 'Sulastri', 'P', 45, 5, 2, 'Sumber', 'SMP', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(30, '3501012345670010', '3501010101100003', 'Fitri Hartono', 'P', 18, 5, 2, 'Sumber', 'SMA', 'Pelajar', 'Belum Kawin', 'Islam'),
(31, '3501012345670011', '3501010101110001', 'Rahmat Hidayat', 'L', 34, 6, 1, 'Krajan', 'S1', 'Guru', 'Kawin', 'Islam'),
(32, '3501012345670011', '3501010101110002', 'Lilis Hidayat', 'P', 30, 6, 1, 'Krajan', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(33, '3501012345670011', '3501010101110003', 'Bayu Hidayat', 'L', 8, 6, 1, 'Krajan', 'SD', 'Pelajar', 'Belum Kawin', 'Islam'),
(34, '3501012345670012', '3501010101120001', 'Sugeng Prayitno', 'L', 52, 6, 2, 'Sumber', 'SMP', 'Petani', 'Kawin', 'Islam'),
(35, '3501012345670012', '3501010101120002', 'Sukarti', 'P', 50, 6, 2, 'Sumber', 'SMP', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(36, '3501012345670013', '3501010101130001', 'Eko Prabowo', 'L', 27, 7, 1, 'Krajan', 'SMA', 'Karyawan', 'Belum Kawin', 'Islam'),
(37, '3501012345670014', '3501010101140001', 'Yuli Astuti', 'P', 33, 7, 2, 'Sumber', 'SMA', 'Pedagang', 'Kawin', 'Islam'),
(38, '3501012345670015', '3501010101150001', 'Darmawan', 'L', 60, 8, 1, 'Krajan', 'SD', 'Pensiunan', 'Kawin', 'Islam'),
(39, '3501012345670015', '3501010101150002', 'Lastri', 'P', 58, 8, 1, 'Krajan', 'SD', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(40, '3501012345670016', '3501010101160001', 'Fajar Nugroho', 'L', 26, 8, 2, 'Sumber', 'D3', 'Programmer', 'Belum Kawin', 'Islam'),
(41, '3501012345670017', '3501010101170001', 'Intan Permata', 'P', 24, 9, 1, 'Krajan', 'S1', 'Perawat', 'Belum Kawin', 'Islam'),
(42, '3501012345670018', '3501010101180001', 'Galih Saputra', 'L', 37, 9, 2, 'Sumber', 'SMA', 'Supir', 'Kawin', 'Islam'),
(43, '3501012345670018', '3501010101180002', 'Rina Saputra', 'P', 35, 9, 2, 'Sumber', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(44, '3501012345670018', '3501010101180003', 'Ayu Saputra', 'P', 10, 9, 2, 'Sumber', 'SD', 'Pelajar', 'Belum Kawin', 'Islam'),
(45, '3501012345670019', '3501010101190001', 'Bayu Setiawan', 'L', 41, 10, 1, 'Krajan', 'S1', 'Wiraswasta', 'Kawin', 'Islam'),
(46, '3501012345670019', '3501010101190002', 'Maya Setiawan', 'P', 39, 10, 1, 'Krajan', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(47, '3501012345670019', '3501010101190003', 'Rafi Setiawan', 'L', 14, 10, 1, 'Krajan', 'SMP', 'Pelajar', 'Belum Kawin', 'Islam'),
(48, '3501012345670020', '3501010101200001', 'Ahmad Fauzi', 'L', 31, 10, 2, 'Sumber', 'S1', 'Programmer', 'Kawin', 'Islam'),
(49, '3501012345670020', '3501010101200002', 'Rina Fauzi', 'P', 28, 10, 2, 'Sumber', 'SMA', 'Ibu Rumah Tangga', 'Kawin', 'Islam'),
(50, '3501012345670020', '3501010101200003', 'Dinda Fauzi', 'P', 6, 10, 2, 'Sumber', 'TK', 'Pelajar', 'Belum Kawin', 'Islam'),
(51, '3501012345670001', '3501012345670023', 'Erick Firmansyah', 'L', 21, 2, 1, 'Rosep Timur', 'S1', 'KKN', 'Kawin', 'Konghucu'),
(52, '3501012345670001', '3501012345670321', 'Muhammad Rizaldi', 'L', 22, 1, 2, 'Kepong', 'SMA', 'Siswa', 'Kawin Tak Tercatat', 'Konghucu');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `profil_desa`
--
ALTER TABLE `profil_desa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_penduduk`
--
ALTER TABLE `t_penduduk`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `profil_desa`
--
ALTER TABLE `profil_desa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `t_penduduk`
--
ALTER TABLE `t_penduduk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
