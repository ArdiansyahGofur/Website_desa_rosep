<?php 
    include '../koneksi/koneksi.php'; 
    include '../includes/header.php'; 

?>

<!-- Konten Utama -->
<h2 class="text-3xl font-bold text-green-800 mb-6">
  Selamat Datang di Infografis Desa 🌾
</h2>
<p class="text-gray-700 mb-8">
  Ini adalah halaman utama untuk  informasi desa.
</p>

<?php

include '../grafis/card_jumlah.php';
include '../grafis/diagram_penduduk.php';
include '../grafis/diagram_dusun.php';
include '../grafis/diagram_pendidikan.php';
include '../grafis/diagram_pekerjaan.php';
include '../grafis/diagram_status.php';
include '../grafis/diagram_agama.php';

?>


<?php include '../includes/footer.php'; ?>
