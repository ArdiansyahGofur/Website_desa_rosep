<?php
include '../koneksi/koneksi.php';
include '../includes/header.php'; 

// Ambil semua berita, urut terbaru
$result = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Berita Desa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-800">



  <!-- Main Content -->
  <main class="max-w-6xl mx-auto px-6 py-12 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <article class="bg-white rounded-xl shadow hover:shadow-lg overflow-hidden flex flex-col transition duration-300">
        <?php if (!empty($row['gambar'])): ?>
          <img src="../admin/uploads/<?= $row['gambar'] ?>" alt="<?= htmlspecialchars($row['judul']) ?>" 
               class="h-48 w-full object-cover">
        <?php else: ?>
          <div class="h-48 w-full bg-green-100 flex items-center justify-center text-green-700 font-semibold">
            Tidak ada gambar
          </div>
        <?php endif; ?>

        <div class="p-6 flex flex-col flex-grow">
          <h2 class="text-xl font-bold text-green-800 mb-2"><?= htmlspecialchars($row['judul']) ?></h2>
          <p class="text-sm text-gray-500 mb-4">
            <?= date('d M Y', strtotime($row['tanggal'])) ?> • <?= htmlspecialchars($row['penulis']) ?>
          </p>
          <p class="text-gray-700 flex-grow">
            <?= substr(strip_tags($row['isi']), 0, 100) ?>...
          </p>
          <a href="berita_detail.php?id=<?= $row['id'] ?>" 
             class="mt-4 inline-block text-green-700 font-semibold hover:text-green-900 transition">
            Baca Selengkapnya →
          </a>
        </div>
      </article>
    <?php endwhile; ?>
  </main>

  <!-- Footer -->
  <?php include '../includes/footer.php' ?>

</body>
</html>
