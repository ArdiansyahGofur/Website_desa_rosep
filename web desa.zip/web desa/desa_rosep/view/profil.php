<?php
include '../koneksi/koneksi.php';
include '../includes/header.php';

// Ambil data profil desa
$result = mysqli_query($conn, "SELECT * FROM profil_desa LIMIT 1");
$data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Desa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-900">

  

  <!-- Main Content -->
  <main class="max-w-6xl mx-auto px-6 py-12 space-y-14">

    <?php
    // Card reusable function
    function card($id, $title, $content) {
      return "
      <section id='$id' class='scroll-mt-24'>
        <h2 class='text-2xl font-bold text-green-800 mb-4 border-l-4 border-green-600 pl-3'>$title</h2>
        <div class='bg-white shadow-lg rounded-xl p-6 md:p-8 hover:shadow-2xl transition duration-300'>
          $content
        </div>
      </section>
      ";
    }
    ?>

    <!-- Visi -->
    <?= card("visi", "Visi", "<p class='leading-relaxed'>" . nl2br($data['visi'] ?? 'Belum ada data') . "</p>") ?>

    <!-- Misi -->
    <?= card("misi", "Misi", "<p class='leading-relaxed'>" . nl2br($data['misi'] ?? 'Belum ada data') . "</p>") ?>

    <!-- Bagan Desa -->
    <?= card("bagan", "Struktur Organisasi", 
      !empty($data['bagan']) 
      ? "<img src='../uploads/{$data['bagan']}' alt='Bagan Desa' class='rounded-lg shadow-md w-full max-w-2xl mx-auto'>" 
      : "<p class='text-gray-500'>Belum ada bagan desa.</p>") 
    ?>

    <!-- Sejarah -->
    <?= card("sejarah", "Sejarah Desa", "<p class='leading-relaxed'>" . nl2br($data['sejarah'] ?? 'Belum ada data') . "</p>") ?>


  </main>

<?php include '../includes/footer.php' ?>

</body>
</html>
