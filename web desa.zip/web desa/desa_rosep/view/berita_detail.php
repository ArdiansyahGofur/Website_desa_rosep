<?php
include '../koneksi/koneksi.php';
include '../includes/header.php'; 

if (!isset($_GET['id'])) {
  die("ID tidak ditemukan!");
}
$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM berita WHERE id=$id");
$data = mysqli_fetch_assoc($result);
if (!$data) {
  die("Berita tidak ditemukan!");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($data['judul']) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 font-sans text-gray-800">

  <!-- Header -->
  <header class="bg-green-700 text-white py-8 shadow-lg">
    <div class="max-w-4xl mx-auto px-6">
      <h1 class="text-3xl font-bold"><?= htmlspecialchars($data['judul']) ?></h1>
      <p class="text-green-200 mt-2 text-sm">
        <?= date('d M Y', strtotime($data['tanggal'])) ?> • <?= htmlspecialchars($data['penulis']) ?>
      </p>
    </div>
  </header>

  <!-- Content -->
  <main class="max-w-4xl mx-auto px-6 py-10">
    <?php if (!empty($data['gambar'])): ?>
      <img src="../admin/uploads/<?= $data['gambar'] ?>" alt="Gambar Berita" 
           class="w-full rounded-lg shadow mb-6">
    <?php endif; ?>

    <div class="bg-white shadow rounded-lg p-6 leading-relaxed">
      <?= nl2br($data['isi']) ?>
    </div>

    <a href="berita.php" class="inline-block mt-6 text-green-700 hover:text-green-900 font-semibold">
      ← Kembali ke Berita
    </a>
  </main>

  <!-- Footer -->
  <?php include '../includes/footer.php' ?>

</body>
</html>
