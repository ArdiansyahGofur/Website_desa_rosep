<?php 
include '../includes/header.php'; 
?>

<div class="max-w-7xl mx-auto px-6 py-8">
  <div class="bg-white shadow-xl rounded-2xl overflow-hidden hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
    
    <!-- Header Card -->
    <div class="p-6 border-b bg-gradient-to-r from-green-600 to-green-700 text-white">
      <h2 class="text-2xl font-bold flex items-center space-x-2">
        <span>🗺️</span>
        <span>Peta Desa Rosep</span>
      </h2>
      <p class="mt-2 flex items-center space-x-2 text-green-100">
        <span>📍</span>
        <span>Desa Rosep, Kecamatan Blega, Kabupaten Bangkalan, Jawa Timur</span>
      </p>
    </div>

    <!-- Map -->
    <div class="relative group">
      <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17711.911799089838!2d113.03814274793534!3d-7.138642593902877!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd82057dbd997b7%3A0xd35514a44da4e4db!2sRosep%2C%20Kec.%20Blega%2C%20Kabupaten%20Bangkalan%2C%20Jawa%20Timur!5e1!3m2!1sid!2sid!4v1758032078796!5m2!1sid!2sid" 
        width="100%" 
        height="500" 
        style="border:0;" 
        allowfullscreen 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade"
        class="w-full h-[500px] transition-transform duration-700 group-hover:scale-105">
      </iframe>

      <!-- Overlay Efek -->
      <div class="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent pointer-events-none rounded-b-2xl"></div>
    </div>
  </div>

  <!-- Informasi Luas Desa -->
  <div class="mt-8">
    <h3 class="text-2xl font-bold text-green-700 mb-4 flex items-center space-x-2">
      <span>📐</span>
      <span>Informasi Luas Wilayah</span>
    </h3>

    <!-- Grid Card -->
    <div class="max-w-7xl mx-auto px-6 py-8 space-y-8">

  <!-- Card Desa Utama -->
  <div class="bg-gradient-to-r from-green-600 to-green-700 shadow-xl rounded-2xl p-8 text-white hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
    <h2 class="text-3xl font-bold flex items-center space-x-2">
      <span>🌳</span>
      <span>Desa Rosep</span>
    </h2>
    <p class="text-green-100 mt-2 text-lg">Luas Wilayah: <span class="font-semibold">385,5 Ha</span></p>
    <p class="mt-1 text-green-200">📍 Kecamatan Blega, Kabupaten Bangkalan, Jawa Timur</p>
  </div>

  <!-- Grid Dusun -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

    <!-- Dusun Kepong -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-500 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Kepong</h4>
      <p class="text-gray-600">71,41 Ha</p>
    </div>

    <!-- Dusun Rosep Barat -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-400 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Rosep Barat</h4>
      <p class="text-gray-600">49,16 Ha</p>
    </div>

    <!-- Dusun Rosep Timur -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-300 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Rosep Timur</h4>
      <p class="text-gray-600">67,82 Ha</p>
    </div>

    <!-- Dusun Brekas -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-600 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Brekas</h4>
      <p class="text-gray-600">72,08 Ha</p>
    </div>

    <!-- Dusun Leggung Utara -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-500 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Leggung Utara</h4>
      <p class="text-gray-600">44,97 Ha</p>
    </div>

    <!-- Dusun Leggung Selatan -->
    <div class="bg-white shadow-lg rounded-xl p-6 border-l-4 border-green-400 hover:shadow-2xl transform hover:-translate-y-1 transition duration-500">
      <h4 class="font-semibold text-green-700 text-lg">🌿 Dusun Leggung Selatan</h4>
      <p class="text-gray-600">52,09 Ha</p>
    </div>

  </div>
</div>

  </div>
</div>



<?php include '../includes/footer.php'; ?>
