<?php 
include 'koneksi/koneksi.php'; 
include 'includes/header.php'; 
?>

<!-- Banner Hero -->
<section class="bg-gradient-to-r from-green-100 to-green-200 rounded-2xl p-8 mb-8 shadow-lg relative overflow-hidden">
  <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
    <div>
      <h1 class="text-4xl md:text-5xl font-bold text-green-800 mb-4">
        Selamat Datang di Dashboard Desa 🌾
      </h1>
      <p class="text-gray-700 text-lg mb-6">
        Pantau informasi desa secara real-time dan kelola data penduduk, pendidikan, pekerjaan, status, dan agama dengan mudah.
      </p>
      <a href="#statistik" class="bg-green-600 text-white px-6 py-3 rounded-lg shadow hover:bg-green-700 transition">
        Lihat Statistik
      </a>
    </div>
    <div class="flex justify-center md:justify-end">
      <img src="assets/illustration-village.png" alt="Desa" class="w-80 md:w-96">
    </div>
  </div>
</section>



<?php include 'includes/footer.php'; ?>
