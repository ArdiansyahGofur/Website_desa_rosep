<?php
$base_url = "/desa_rosep/"; // atau "/project-folder/" kalau pakai localhost
?>
