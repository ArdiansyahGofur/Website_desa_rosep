<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

// Ambil data berita
$query = "SELECT * FROM berita ORDER BY tanggal DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Berita Desa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<main id="mainContent" class="ml-64 p-8">
  <h2 class="text-3xl font-bold text-green-800 mb-6">📰 Kelola Berita Desa</h2>

  <a href="tambah_berita.php" class="bg-green-600 text-white px-4 py-2 rounded shadow hover:bg-green-700">
    + Tambah Berita
  </a>

  <div class="bg-white shadow-md rounded-lg mt-6 p-6">
  <table class="min-w-full border border-gray-300 text-sm">
    <thead class="bg-green-700 text-white">
      <tr>
        <th class="px-4 py-2 border">Gambar</th>
        <th class="px-4 py-2 border">Judul</th>
        <th class="px-4 py-2 border">Tanggal</th>
        <th class="px-4 py-2 border">Penulis</th>
        <th class="px-4 py-2 border">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr class="hover:bg-gray-50 odd:bg-gray-100">
            
            <!-- Kolom Gambar -->
            <td class="px-4 py-2 border text-center">
              <?php if (!empty($row['gambar'])): ?>
                <img src="uploads/<?= $row['gambar']; ?>" 
                     alt="<?= htmlspecialchars($row['judul']); ?>" 
                     class="w-16 h-16 object-cover rounded mx-auto">
              <?php else: ?>
                <span class="text-gray-400 italic">-</span>
              <?php endif; ?>
            </td>

            <td class="px-4 py-2 border"><?= htmlspecialchars($row['judul']); ?></td>
            <td class="px-4 py-2 border"><?= $row['tanggal']; ?></td>
            <td class="px-4 py-2 border"><?= $row['penulis']; ?></td>
            <td class="px-4 py-2 border text-center">
              <a href="edit_berita.php?id=<?= $row['id']; ?>" class="bg-yellow-500 text-white px-2 py-1 rounded">Edit</a>
              <a href="hapus_berita.php?id=<?= $row['id']; ?>" 
                 onclick="return confirm('Yakin ingin hapus berita ini?');"
                 class="bg-red-600 text-white px-2 py-1 rounded">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="5" class="text-center text-gray-500 py-4">Belum ada berita.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

</main>

</body>
</html>
