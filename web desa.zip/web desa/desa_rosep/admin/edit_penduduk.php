<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

// Ambil data lama
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $result = mysqli_query($conn, "SELECT * FROM t_penduduk WHERE id='$id'");
  $data = mysqli_fetch_assoc($result);

  if (!$data) {
    die("Data tidak ditemukan!");
  }
}

// Proses update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id         = $_POST['id'];
  $no_kk      = $_POST['no_kk'];
  $nik        = $_POST['nik'];
  $nama       = $_POST['nama'];
  $kelamin    = $_POST['kelamin'];
  $usia       = $_POST['usia'];
  $rt         = $_POST['rt'];
  $rw         = $_POST['rw'];
  $dusun      = $_POST['dusun'];
  $pendidikan = $_POST['pendidikan'];
  $pekerjaan  = $_POST['pekerjaan'];
  $status     = $_POST['status'];
  $agama      = $_POST['agama'];

  $sql = "UPDATE t_penduduk SET 
            no_kk='$no_kk',
            nik='$nik',
            nama='$nama',
            kelamin='$kelamin',
            usia='$usia',
            rt='$rt',
            rw='$rw',
            dusun='$dusun',
            pendidikan='$pendidikan',
            pekerjaan='$pekerjaan',
            status='$status',
            agama='$agama'
          WHERE id='$id'";

  if (mysqli_query($conn, $sql)) {
    header("Location: data_penduduk.php?updated=1");
    exit;
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Penduduk</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Konten utama, geser kanan biar tidak bentrok dengan sidebar -->
  <main class="ml-64 p-8">
    <h2 class="text-3xl font-extrabold text-yellow-700 mb-6 flex items-center gap-2">
      ✏️ Edit Data Penduduk
    </h2>

    <div class="bg-white p-8 rounded-2xl shadow-lg max-w-3xl">
      <form method="POST" class="grid grid-cols-2 gap-6">
        <input type="hidden" name="id" value="<?= $data['id']; ?>">

        <!-- No KK -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">No KK</label>
          <input type="text" name="no_kk" value="<?= $data['no_kk']; ?>" maxlength="16" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- NIK -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">NIK</label>
          <input type="text" name="nik" value="<?= $data['nik']; ?>" maxlength="16" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- Nama -->
        <div class="col-span-2">
          <label class="block text-sm font-semibold mb-1 text-gray-700">Nama Lengkap</label>
          <input type="text" name="nama" value="<?= $data['nama']; ?>" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- Kelamin -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Jenis Kelamin</label>
          <select name="kelamin"
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
            <option value="L" <?= $data['kelamin'] == 'L' ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="P" <?= $data['kelamin'] == 'P' ? 'selected' : ''; ?>>Perempuan</option>
          </select>
        </div>

        <!-- Usia -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Usia</label>
          <input type="number" name="usia" value="<?= $data['usia']; ?>" min="0" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- RT -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">RT</label>
          <input type="text" name="rt" value="<?= $data['rt']; ?>"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- RW -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">RW</label>
          <input type="text" name="rw" value="<?= $data['rw']; ?>"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- Dusun -->
        <div class="col-span-2">
          <label class="block text-sm font-semibold mb-1 text-gray-700">Dusun</label>
          <select name="dusun" class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
            <option value="Kepong" <?= $data['dusun']=='Kepong'?'selected':''; ?>>Kepong</option>
            <option value="Rosep Barat" <?= $data['dusun']=='Rosep Barat'?'selected':''; ?>>Rosep Barat</option>
            <option value="Rosep Timur" <?= $data['dusun']=='Rosep Timur'?'selected':''; ?>>Rosep Timur</option>
            <option value="Brekas" <?= $data['dusun']=='Brekas'?'selected':''; ?>>Brekas</option>
            <option value="Leggung Utara" <?= $data['dusun']=='Leggung Utara'?'selected':''; ?>>Leggung Utara</option>
            <option value="Leggung Selatan" <?= $data['dusun']=='Leggung Selatan'?'selected':''; ?>>Leggung Selatan</option>
          </select>
        </div>

        <!-- Pendidikan -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Pendidikan</label>
          <input type="text" name="pendidikan" value="<?= $data['pendidikan']; ?>"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- Pekerjaan -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Pekerjaan</label>
          <input type="text" name="pekerjaan" value="<?= $data['pekerjaan']; ?>"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
        </div>

        <!-- Status -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Status</label>
          <select name="status" class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
            <option value="Belum Kawin" <?= $data['status']=='Belum Kawin'?'selected':''; ?>>Belum Kawin</option>
            <option value="Kawin" <?= $data['status']=='Kawin'?'selected':''; ?>>Kawin</option>
            <option value="Cerai Mati" <?= $data['status']=='Cerai Mati'?'selected':''; ?>>Cerai Mati</option>
            <option value="Cerai Hidup" <?= $data['status']=='Cerai Hidup'?'selected':''; ?>>Cerai Hidup</option>
            <option value="Kawin Tercatat" <?= $data['status']=='Kawin Tercatat'?'selected':''; ?>>Kawin Tercatat</option>
            <option value="Kawin Tak Tercatat" <?= $data['status']=='Kawin Tak Tercatat'?'selected':''; ?>>Kawin Tak Tercatat</option>
          </select>
        </div>

        <!-- Agama -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Agama</label>
          <select name="agama" class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-yellow-500 outline-none">
            <option value="Islam" <?= $data['agama']=='Islam'?'selected':''; ?>>Islam</option>
            <option value="Kristen" <?= $data['agama']=='Kristen'?'selected':''; ?>>Kristen</option>
            <option value="Katolik" <?= $data['agama']=='Katolik'?'selected':''; ?>>Katolik</option>
            <option value="Hindu" <?= $data['agama']=='Hindu'?'selected':''; ?>>Hindu</option>
            <option value="Budha" <?= $data['agama']=='Budha'?'selected':''; ?>>Budha</option>
            <option value="Konghucu" <?= $data['agama']=='Konghucu'?'selected':''; ?>>Konghucu</option>
            <option value="Kepercayaan Lainnya" <?= $data['agama']=='Kepercayaan Lainnya'?'selected':''; ?>>Kepercayaan Lainnya</option>
          </select>
        </div>

        <!-- Tombol -->
        <div class="col-span-2 flex justify-between mt-4">
          <a href="penduduk.php" class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-lg shadow-md transition">
            ⬅ Kembali
          </a>
          <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-2 rounded-lg shadow-md transition">
            💾 Update
          </button>
        </div>
      </form>
    </div>
  </main>
</body>
</html>
