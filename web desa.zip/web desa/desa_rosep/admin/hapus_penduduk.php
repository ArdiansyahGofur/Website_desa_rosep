<?php
include '../koneksi/koneksi.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];

  $sql = "DELETE FROM t_penduduk WHERE id='$id'";
  if (mysqli_query($conn, $sql)) {
    header("Location: penduduk.php");
    exit;
  } else {
    echo "Error: " . mysqli_error($conn);
  }
} else {
  header("Location: penduduk.php");
  exit;
}
?>
