<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

// Ambil data lama
if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $result = mysqli_query($conn, "SELECT * FROM berita WHERE id=$id");
  $data = mysqli_fetch_assoc($result);

  if (!$data) {
    die("Berita tidak ditemukan!");
  }
} else {
  die("ID tidak valid!");
}

// Proses update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $judul   = mysqli_real_escape_string($conn, $_POST['judul']);
  $isi     = mysqli_real_escape_string($conn, $_POST['isi']);
  $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);

  // Cek apakah ada gambar baru
  $gambar = $data['gambar'];
  if (!empty($_FILES['gambar']['name'])) {
    $target = "uploads/" . basename($_FILES['gambar']['name']);
    if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target)) {
      $gambar = $_FILES['gambar']['name'];
    }
  }

  $sql = "UPDATE berita SET 
            judul='$judul',
            isi='$isi',
            penulis='$penulis',
            gambar='$gambar'
          WHERE id=$id";

  if (mysqli_query($conn, $sql)) {
    header("Location: berita.php");
    exit;
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Berita</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Konten utama -->
  <div class="ml-64 p-8"> <!-- ml-64 supaya tidak ketabrak sidebar -->
    <h2 class="text-2xl font-bold mb-6">Edit Berita</h2>

    <form method="POST" enctype="multipart/form-data" 
          class="space-y-4 bg-white shadow-md rounded-lg p-6 max-w-2xl">
      
      <div>
        <label class="block mb-1 font-semibold">Judul</label>
        <input type="text" name="judul" value="<?= htmlspecialchars($data['judul']) ?>" 
               required class="w-full border px-3 py-2 rounded">
      </div>

      <div>
        <label class="block mb-1 font-semibold">Isi</label>
        <textarea name="isi" rows="6" required 
                  class="w-full border px-3 py-2 rounded"><?= htmlspecialchars($data['isi']) ?></textarea>
      </div>

      <div>
        <label class="block mb-1 font-semibold">Penulis</label>
        <input type="text" name="penulis" value="<?= htmlspecialchars($data['penulis']) ?>" 
               required class="w-full border px-3 py-2 rounded">
      </div>

      <div>
        <label class="block mb-1 font-semibold">Gambar</label>
        <?php if (!empty($data['gambar'])): ?>
          <img src="uploads/<?= $data['gambar'] ?>" alt="Gambar Berita" class="w-40 rounded mb-2">
        <?php endif; ?>
        <input type="file" name="gambar" class="w-full">
      </div>

      <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Update</button>
    </form>
  </div>

</body>
</html>
