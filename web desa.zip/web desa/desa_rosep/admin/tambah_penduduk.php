<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $no_kk      = mysqli_real_escape_string($conn, $_POST['no_kk']);
  $nik        = mysqli_real_escape_string($conn, $_POST['nik']);
  $nama       = mysqli_real_escape_string($conn, $_POST['nama']);
  $kelamin    = mysqli_real_escape_string($conn, $_POST['kelamin']);
  $usia       = (int) $_POST['usia'];
  $rt         = mysqli_real_escape_string($conn, $_POST['rt']);
  $rw         = mysqli_real_escape_string($conn, $_POST['rw']);
  $dusun      = mysqli_real_escape_string($conn, $_POST['dusun']);
  $pendidikan = mysqli_real_escape_string($conn, $_POST['pendidikan']);
  $pekerjaan  = mysqli_real_escape_string($conn, $_POST['pekerjaan']);
  $status     = mysqli_real_escape_string($conn, $_POST['status']);
  $agama      = mysqli_real_escape_string($conn, $_POST['agama']);

  $sql = "INSERT INTO t_penduduk 
          (no_kk, nik, nama, kelamin, usia, rt, rw, dusun, pendidikan, pekerjaan, status, agama)
          VALUES ('$no_kk','$nik','$nama','$kelamin','$usia','$rt','$rw','$dusun','$pendidikan','$pekerjaan','$status','$agama')";

  if (mysqli_query($conn, $sql)) {
    header("Location: penduduk.php");
    exit;
  } else {
    echo "<p class='text-red-600 font-bold ml-64 mt-4'>Error: " . mysqli_error($conn) . "</p>";
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Penduduk</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <main class="ml-64 p-8 transition-all duration-300">
    <h2 class="text-3xl font-extrabold text-green-800 mb-6 flex items-center gap-2">
      ➕ Tambah Data Penduduk
    </h2>

    <div class="bg-white p-8 rounded-2xl shadow-lg max-w-3xl">
      <form method="POST" class="grid grid-cols-2 gap-6">
        <!-- No KK -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">No KK</label>
          <input type="text" name="no_kk" maxlength="16" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- NIK -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">NIK</label>
          <input type="text" name="nik" maxlength="16" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- Nama -->
        <div class="col-span-2">
          <label class="block text-sm font-semibold mb-1 text-gray-700">Nama Lengkap</label>
          <input type="text" name="nama" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- Kelamin -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Jenis Kelamin</label>
          <select name="kelamin" required
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
            <option value="">-- Pilih --</option>
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
          </select>
        </div>

        <!-- Usia -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Usia</label>
          <input type="number" name="usia" min="0" required
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- RT -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">RT</label>
          <input type="text" name="rt"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- RW -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">RW</label>
          <input type="text" name="rw"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- Dusun -->
        <div class="col-span-2">
          <label class="block text-sm font-semibold mb-1 text-gray-700">Dusun</label>
          <select name="dusun" required
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
            <option value="">-- Pilih Dusun --</option>
            <option value="Kepong">Kepong</option>
            <option value="Rosep Barat">Rosep Barat</option>
            <option value="Rosep Timur">Rosep Timur</option>
            <option value="Brekas">Brekas</option>
            <option value="Leggung Utara">Leggung Utara</option>
            <option value="Leggung Selatan">Leggung Selatan</option>
          </select>
        </div>

        <!-- Pendidikan -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Pendidikan</label>
          <select name="pendidikan"
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
            <option value="">-- Pilih Pendidikan --</option>
            <option value="Tidak Sekolah">Tidak Sekolah</option>
            <option value="SD">SD / Sederajat</option>
            <option value="SMP">SMP / Sederajat</option>
            <option value="SMA">SMA / Sederajat</option>
            <option value="Diploma 1">Diploma 1 (D1)</option>
            <option value="Diploma 2">Diploma 2 (D2)</option>
            <option value="Diploma 3">Diploma 3 (D3)</option>
            <option value="Diploma 4">Diploma 4 (D4)</option>
            <option value="Strata 1">Strata 1 (S1)</option>
            <option value="Strata 2">Strata 2 (S2)</option>
            <option value="Strata 3">Strata 3 (S3)</option>
          </select>
        </div>


        <!-- Pekerjaan -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Pekerjaan</label>
          <input type="text" name="pekerjaan"
                 class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
        </div>

        <!-- Status -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Status</label>
          <select name="status" required
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
            <option value="">-- Pilih Status --</option>
            <option value="Belum Kawin">Belum Kawin</option>
            <option value="Kawin">Kawin</option>
            <option value="Cerai Mati">Cerai Mati</option>
            <option value="Cerai Hidup">Cerai Hidup</option>
            <option value="Kawin Tercatat">Kawin Tercatat</option>
            <option value="Kawin Tak Tercatat">Kawin Tak Tercatat</option>
          </select>
        </div>

        <!-- Agama -->
        <div>
          <label class="block text-sm font-semibold mb-1 text-gray-700">Agama</label>
          <select name="agama" required
                  class="border px-4 py-2 rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none">
            <option value="">-- Pilih Agama --</option>
            <option value="Islam">Islam</option>
            <option value="Kristen">Kristen</option>
            <option value="Katolik">Katolik</option>
            <option value="Hindu">Hindu</option>
            <option value="Budha">Budha</option>
            <option value="Konghucu">Konghucu</option>
            <option value="Kepercayaan Lainnya">Kepercayaan Lainnya</option>
          </select>
        </div>

        <!-- Tombol -->
        <div class="col-span-2 flex justify-between mt-4">
          <a href="penduduk.php" class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-lg shadow-md transition">
            ⬅ Kembali
          </a>
          <button type="submit" 
                  class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg shadow-md transition">
            💾 Simpan
          </button>
        </div>
      </form>
    </div>
  </main>

</body>
</html>
