<?php
include '../koneksi/koneksi.php';

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  mysqli_query($conn, "DELETE FROM berita WHERE id=$id");
}
header("Location: berita_desa.php");
