<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

// Ambil data profil (hanya 1 baris)
$result = mysqli_query($conn, "SELECT * FROM profil_desa LIMIT 1");
$data   = mysqli_fetch_assoc($result);

$success = ""; // pesan sukses

// Proses update / insert
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $visi    = mysqli_real_escape_string($conn, $_POST['visi']);
  $misi    = mysqli_real_escape_string($conn, $_POST['misi']);
  $sejarah = mysqli_real_escape_string($conn, $_POST['sejarah']);

  // Upload gambar bagan
  $bagan = $data['bagan'] ?? '';
  if (!empty($_FILES['bagan']['name'])) {
    $targetDir = "../uploads/";
    if (!file_exists($targetDir)) {
      mkdir($targetDir, 0777, true);
    }
    $fileName   = time() . "_" . basename($_FILES['bagan']['name']);
    $targetFile = $targetDir . $fileName;
    if (move_uploaded_file($_FILES['bagan']['tmp_name'], $targetFile)) {
      $bagan = $fileName;
    }
  }

  if ($data) {
    // Update
    $sql = "UPDATE profil_desa 
            SET visi='$visi', misi='$misi', sejarah='$sejarah', bagan='$bagan' 
            WHERE id={$data['id']}";
  } else {
    // Insert
    $sql = "INSERT INTO profil_desa (visi, misi, sejarah, bagan) 
            VALUES ('$visi','$misi','$sejarah','$bagan')";
  }

  if (mysqli_query($conn, $sql)) {
    $success = "Profil desa berhasil disimpan ✅";
    // Ambil ulang data terbaru
    $result = mysqli_query($conn, "SELECT * FROM profil_desa LIMIT 1");
    $data   = mysqli_fetch_assoc($result);
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin Profil Desa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">
  <main id="mainContent" class="flex-1 p-8 ml-64 transition-all duration-300">
    <h2 class="text-3xl font-bold text-gray-800 mb-6">🏡 Profil Desa</h2>

    <!-- Alert sukses -->
    <?php if (!empty($success)): ?>
      <div class="mb-6 p-4 bg-green-100 text-green-800 rounded-lg border border-green-300">
        <?= $success ?>
      </div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded-lg shadow grid gap-6">
      
      <!-- Visi -->
      <div>
        <label class="block font-semibold mb-2">Visi</label>
        <textarea name="visi" rows="3" class="w-full border rounded-lg p-3"><?= $data['visi'] ?? '' ?></textarea>
      </div>

      <!-- Misi -->
      <div>
        <label class="block font-semibold mb-2">Misi</label>
        <textarea name="misi" rows="4" class="w-full border rounded-lg p-3"><?= $data['misi'] ?? '' ?></textarea>
      </div>

      <!-- Bagan Desa -->
      <div>
        <label class="block font-semibold mb-2">Bagan Desa (Upload Gambar)</label>
        <?php if (!empty($data['bagan'])): ?>
          <img src="../uploads/<?= $data['bagan'] ?>" alt="Bagan Desa" class="mb-2 w-64 border rounded">
        <?php endif; ?>
        <input type="file" name="bagan" accept="image/*" class="w-full border rounded-lg p-2">
      </div>

      <!-- Sejarah -->
      <div>
        <label class="block font-semibold mb-2">Sejarah Desa</label>
        <textarea name="sejarah" rows="6" class="w-full border rounded-lg p-3"><?= $data['sejarah'] ?? '' ?></textarea>
      </div>

      <!-- Tombol Simpan -->
      <div class="pt-4">
        <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
          Simpan Perubahan
        </button>
      </div>
    </form>
  </main>
</body>
</html>
