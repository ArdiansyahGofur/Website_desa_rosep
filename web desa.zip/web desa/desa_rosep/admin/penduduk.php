<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

// Cek apakah ada pencarian
$search = "";
if (isset($_GET['search'])) {
  $search = mysqli_real_escape_string($conn, $_GET['search']);
  $query = "SELECT * FROM t_penduduk 
            WHERE no_kk LIKE '%$search%' 
               OR nik LIKE '%$search%' 
               OR nama LIKE '%$search%' 
               OR kelamin LIKE '%$search%' 
               OR usia LIKE '%$search%' 
               OR rt LIKE '%$search%' 
               OR rw LIKE '%$search%' 
               OR dusun LIKE '%$search%' 
               OR pendidikan LIKE '%$search%' 
               OR pekerjaan LIKE '%$search%' 
               OR status LIKE '%$search%' 
               OR agama LIKE '%$search%'";
} else {
  $query = "SELECT * FROM t_penduduk";
}
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Penduduk</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-100 font-sans">

  <!-- Main Content -->
  <main id="mainContent" class="flex-1 p-8 ml-64 transition-all duration-300">
    <!-- Header -->
    <div class="flex justify-between items-center mb-6">
      <h2 class="text-3xl font-bold text-gray-800 flex items-center gap-2">
        📋 Data Penduduk
      </h2>
      <a href="tambah_penduduk.php" 
         class="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white px-4 py-2 rounded-lg shadow hover:opacity-90 transition">
        <i data-lucide="plus-circle" class="w-5 h-5"></i> Tambah
      </a>
    </div>

    <!-- Form Pencarian -->
    <form method="GET" 
          class="mb-6 bg-white p-4 rounded-lg shadow flex items-center gap-2">
      <input type="text" name="search" value="<?= $search; ?>" 
             placeholder="🔍 Cari berdasarkan nama, NIK, dusun, dll..." 
             class="border px-4 py-2 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-green-500">
      <button type="submit" 
              class="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg shadow hover:bg-green-700 transition">
        <i data-lucide="search" class="w-4 h-4"></i> Cari
      </button>
    </form>

    <!-- Tabel Data -->
    <div class="bg-white shadow-lg rounded-xl overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full border-collapse text-sm">
          <thead>
            <tr class="bg-gradient-to-r from-green-600 to-green-500 text-white">
              <th class="px-4 py-3 text-left">No KK</th>
              <th class="px-4 py-3 text-left">NIK</th>
              <th class="px-4 py-3 text-left">Nama</th>
              <th class="px-4 py-3 text-center">L/P</th>
              <th class="px-4 py-3 text-center">Usia</th>
              <th class="px-4 py-3 text-center">RT</th>
              <th class="px-4 py-3 text-center">RW</th>
              <th class="px-4 py-3 text-left">Dusun</th>
              <th class="px-4 py-3 text-left">Pendidikan</th>
              <th class="px-4 py-3 text-left">Pekerjaan</th>
              <th class="px-4 py-3 text-left">Status</th>
              <th class="px-4 py-3 text-left">Agama</th>
              <th class="px-4 py-3 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
              <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr class="hover:bg-gray-50 even:bg-gray-100 transition">
                  <td class="px-4 py-3"><?= $row['no_kk']; ?></td>
                  <td class="px-4 py-3"><?= $row['nik']; ?></td>
                  <td class="px-4 py-3 font-medium"><?= $row['nama']; ?></td>
                  <td class="px-4 py-3 text-center"><?= $row['kelamin']; ?></td>
                  <td class="px-4 py-3 text-center"><?= $row['usia']; ?></td>
                  <td class="px-4 py-3 text-center"><?= $row['rt']; ?></td>
                  <td class="px-4 py-3 text-center"><?= $row['rw']; ?></td>
                  <td class="px-4 py-3"><?= $row['dusun']; ?></td>
                  <td class="px-4 py-3"><?= $row['pendidikan']; ?></td>
                  <td class="px-4 py-3"><?= $row['pekerjaan']; ?></td>
                  <td class="px-4 py-3"><?= $row['status']; ?></td>
                  <td class="px-4 py-3"><?= $row['agama']; ?></td>
                  <td class="px-4 py-3 flex gap-2 justify-center">
                    <a href="edit_penduduk.php?id=<?= $row['id']; ?>" 
                       class="flex items-center gap-1 bg-yellow-500 text-white px-3 py-1 rounded-lg hover:bg-yellow-600 transition shadow">
                      <i data-lucide="edit-3" class="w-4 h-4"></i> Edit
                    </a>
                    <a href="hapus_penduduk.php?id=<?= $row['id']; ?>" 
                       onclick="return confirm('Yakin ingin hapus?');"
                       class="flex items-center gap-1 bg-red-600 text-white px-3 py-1 rounded-lg hover:bg-red-700 transition shadow">
                      <i data-lucide="trash-2" class="w-4 h-4"></i> Hapus
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="13" class="px-4 py-6 text-center text-gray-500">
                  Tidak ada data penduduk.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <!-- Script Sinkronisasi Sidebar & Main -->
  <script>
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('toggleSidebar');
    const toggleIcon = document.getElementById('toggleIcon');
    const mainContent = document.getElementById('mainContent');

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('w-64');
      sidebar.classList.toggle('w-20');
      mainContent.classList.toggle('ml-64');
      mainContent.classList.toggle('ml-20');

      document.querySelectorAll('.sidebar-text').forEach(el => {
        el.classList.toggle('hidden');
      });

      toggleIcon.textContent = sidebar.classList.contains('w-64') ? '«' : '»';
    });

    // Aktifkan ikon lucide
    lucide.createIcons();
  </script>
</body>
</html>
