<?php
include '../koneksi/koneksi.php';
include '../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $judul = mysqli_real_escape_string($conn, $_POST['judul']);
  $isi = mysqli_real_escape_string($conn, $_POST['isi']);
  $tanggal = date('Y-m-d');
  $penulis = "Admin";

  // Upload gambar
  $gambar = null;
  if (!empty($_FILES['gambar']['name'])) {
    $uploadDir = __DIR__ . "/uploads/"; // pastikan folder ada
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0777, true); // buat folder kalau belum ada
    }

    $filename = time() . "_" . basename($_FILES['gambar']['name']); // supaya unik
    $target = $uploadDir . $filename;

    if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target)) {
      $gambar = $filename;
    } else {
      die("Upload gagal! Cek folder / permission.");
    }
  }

  mysqli_query($conn, "INSERT INTO berita (judul, isi, gambar, tanggal, penulis) 
                       VALUES ('$judul', '$isi', '$gambar', '$tanggal', '$penulis')");
  header("Location: berita_desa.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Berita</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
  <!-- Konten utama -->
  <div class="ml-64 p-8">
    <h2 class="text-2xl font-bold mb-6">Tambah Berita</h2>
    <form method="POST" enctype="multipart/form-data" 
          class="space-y-4 bg-white shadow-md rounded-lg p-6 max-w-2xl">
      
      <div>
        <label class="block mb-1">Judul</label>
        <input type="text" name="judul" required class="w-full border px-3 py-2 rounded">
      </div>
      
      <div>
        <label class="block mb-1">Isi</label>
        <textarea name="isi" rows="6" required class="w-full border px-3 py-2 rounded"></textarea>
      </div>
      
      <div>
        <label class="block mb-1">Gambar</label>
        <input type="file" name="gambar" accept="image/*" class="w-full">
      </div>
      
      <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Simpan</button>
    </form>
  </div>
</body>
</html>
