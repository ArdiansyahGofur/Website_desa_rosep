<?php 
include '../koneksi/koneksi.php'; 
// include '../includes/header.php'; 
include '../includes/sidebar.php'; 

// Hitung jumlah penduduk
$q1 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk");
$total_penduduk = mysqli_fetch_assoc($q1)['total'];

// Hitung jumlah dusun
$q2 = mysqli_query($conn, "SELECT COUNT(DISTINCT dusun) AS total FROM t_penduduk");
$total_dusun = mysqli_fetch_assoc($q2)['total'];

// Hitung jumlah RW (unik per dusun)
$q3 = mysqli_query($conn, "SELECT COUNT(DISTINCT CONCAT(dusun,'-',rw)) AS total FROM t_penduduk");
$total_rw = mysqli_fetch_assoc($q3)['total'];

// Hitung jumlah RT (unik per dusun)
$q4 = mysqli_query($conn, "SELECT COUNT(DISTINCT CONCAT(dusun,'-',rw,'-',rt)) AS total FROM t_penduduk");
$total_rt = mysqli_fetch_assoc($q4)['total'];

// Hitung jumlah laki-laki
$q5 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk WHERE kelamin='L'");
$total_laki = mysqli_fetch_assoc($q5)['total'];

// Hitung jumlah perempuan
$q6 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk WHERE kelamin='P'");
$total_perempuan = mysqli_fetch_assoc($q6)['total'];

// Hitung jumlah keluarga (berdasarkan no_kk unik)
$q7 = mysqli_query($conn, "SELECT COUNT(DISTINCT no_kk) AS total FROM t_penduduk");
$total_keluarga = mysqli_fetch_assoc($q7)['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

  <!-- Konten Utama -->
  <section class="flex-1 p-8 ml-64">
  <h2 class="text-3xl font-bold text-green-800 mb-2">📊 Admin Dashboard</h2>
  <p class="text-gray-600 mb-8">Ringkasan data desa dalam bentuk statistik.</p>

  <!-- Grid Statistik -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    
    <!-- Card -->
    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-green-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-green-100 p-4 rounded-xl text-2xl">👨‍👩‍👧‍👦</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Jumlah Penduduk</h3>
        <p class="text-3xl font-bold text-green-700"><?= $total_penduduk; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-blue-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-blue-100 p-4 rounded-xl text-2xl">🏡</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Jumlah Dusun</h3>
        <p class="text-3xl font-bold text-blue-700"><?= $total_dusun; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-orange-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-orange-100 p-4 rounded-xl text-2xl">👪</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Jumlah Keluarga</h3>
        <p class="text-3xl font-bold text-orange-700"><?= $total_keluarga; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-purple-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-purple-100 p-4 rounded-xl text-2xl">📌</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Jumlah RW</h3>
        <p class="text-3xl font-bold text-purple-700"><?= $total_rw; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-yellow-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-yellow-100 p-4 rounded-xl text-2xl">🛖</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Jumlah RT</h3>
        <p class="text-3xl font-bold text-yellow-700"><?= $total_rt; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-indigo-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-indigo-100 p-4 rounded-xl text-2xl">👨</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Laki-laki</h3>
        <p class="text-3xl font-bold text-indigo-700"><?= $total_laki; ?></p>
      </div>
    </div>

    <div class="bg-white shadow-lg rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-pink-600 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div class="bg-pink-100 p-4 rounded-xl text-2xl">👩</div>
      <div>
        <h3 class="text-lg font-semibold text-gray-700">Perempuan</h3>
        <p class="text-3xl font-bold text-pink-700"><?= $total_perempuan; ?></p>
      </div>
    </div>

  </div>
</section>


</body>
</html>
