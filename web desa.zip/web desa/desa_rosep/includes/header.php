<?php
include(__DIR__ . '/../config.php');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Desa</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-green-50 font-sans">
    <!-- Header -->
    <header class="bg-gradient-to-r from-green-700 via-green-600 to-green-500 text-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <!-- Logo & Judul -->
            <div class="flex items-center space-x-3">
                <img src="assets/img/logo.png" alt="Logo Desa" 
                     class="w-12 h-12 rounded-full border-2 border-white shadow-md hover:scale-105 transition-transform">
                <h1 class="text-2xl font-bold tracking-wide hover:tracking-wider transition-all duration-300">
                    Website Desa
                </h1>
            </div>

            <!-- Navigasi -->
            <nav>
                <ul class="flex space-x-6 font-medium">
                    <li>
                        <a href="<?= $base_url; ?>index.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Home
                        </a>
                    </li>
                    <li>
                        <a href="<?= $base_url; ?>view/profil.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Profil Desa
                        </a>
                    </li>
                    <li>
                        <a href="<?= $base_url; ?>view/infografis.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Infografis
                        </a>
                    </li>
                    <li>
                        <a href="<?= $base_url; ?>view/lokasi.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Lokasi
                        </a>
                    </li>
                    <li>
                        <a href="<?= $base_url; ?>view/berita.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Berita
                        </a>
                    </li>
                    <li>
                        <a href="<?= $base_url; ?>view/kontak.php" 
                           class="relative hover:text-yellow-300 transition duration-300 after:content-[''] after:block after:w-0 after:h-[2px] after:bg-yellow-300 after:transition-all after:duration-300 hover:after:w-full">
                           Kontak
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Konten utama -->
    <main class="max-w-7xl mx-auto px-6 py-8">
