</main>

<!-- Footer -->
<footer class="bg-green-800 text-white pt-10 pb-6 mt-10">
  <div class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
    
    <!-- Profil Desa -->
    <div>
      <h3 class="text-lg font-bold mb-4">🌾 Profil Desa</h3>
      <p class="text-sm leading-relaxed">
        Website resmi Desa Contoh sebagai pusat informasi, layanan publik, dan berita terkini bagi masyarakat desa.
      </p>
    </div>

    <!-- Navigasi Cepat -->
    <div>
      <h3 class="text-lg font-bold mb-4">🔗 Navigasi Cepat</h3>
      <ul class="space-y-2 text-sm">
        <li><a href="index.php" class="hover:text-yellow-400 transition">Beranda</a></li>
        <li><a href="profil.php" class="hover:text-yellow-400 transition">Profil Desa</a></li>
        <li><a href="berita.php" class="hover:text-yellow-400 transition">Berita</a></li>
        <li><a href="galeri.php" class="hover:text-yellow-400 transition">Galeri</a></li>
        <li><a href="kontak.php" class="hover:text-yellow-400 transition">Kontak</a></li>
      </ul>
    </div>

    <!-- Kontak -->
    <div>
      <h3 class="text-lg font-bold mb-4">📞 Kontak</h3>
      <ul class="text-sm space-y-2">
        <li>📍 Alamat: Jl. Raya Desa No. 123</li>
        <li>📧 Email: info@desacontoh.go.id</li>
        <li>☎️ Telp: (021) 1234 5678</li>
        <li>⏰ Jam Layanan: Senin - Jumat, 08.00 - 16.00</li>
      </ul>
    </div>

    <!-- Sosial Media -->
    <div>
      <h3 class="text-lg font-bold mb-4">🌐 Ikuti Kami</h3>
      <div class="flex space-x-4">
        <a href="#" class="w-9 h-9 flex items-center justify-center bg-green-600 rounded-full hover:bg-yellow-400 transition">
          <i class="fab fa-facebook-f"></i>
        </a>
        <a href="#" class="w-9 h-9 flex items-center justify-center bg-green-600 rounded-full hover:bg-yellow-400 transition">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="#" class="w-9 h-9 flex items-center justify-center bg-green-600 rounded-full hover:bg-yellow-400 transition">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="#" class="w-9 h-9 flex items-center justify-center bg-green-600 rounded-full hover:bg-yellow-400 transition">
          <i class="fab fa-youtube"></i>
        </a>
      </div>
    </div>
  </div>

  <!-- Copyright -->
  <div class="border-t border-green-600 mt-8 pt-4 text-center text-sm">
    &copy; <?php echo date('Y'); ?> Website Desa. Semua Hak Dilindungi.
  </div>
</footer>

<!-- FontAwesome -->
<script src="https://kit.fontawesome.com/yourkitid.js" crossorigin="anonymous"></script>
</body>
</html>
