<!-- Sidebar -->
<aside id="sidebar"
  class="fixed top-0 left-0 w-64 h-screen bg-gradient-to-b from-green-700/90 to-green-900/90 backdrop-blur-lg text-white p-5 shadow-2xl overflow-y-auto no-scrollbar transition-all duration-300 z-50 flex flex-col justify-between">
  
  <!-- Bagian Atas -->
  <div>
    <!-- Logo / Judul -->
    <div class="flex items-center mb-10 sidebar-header transition-all duration-300">
      <div class="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mr-3 shadow-md">
        <span class="text-2xl">🌿</span>
      </div>
      <h2 class="text-2xl font-extrabold tracking-wide sidebar-text">Admin Desa</h2>
    </div>

    <!-- Navigasi -->
    <nav>
      <ul class="space-y-2">
        <li>
          <a href="dasboard.php" class="flex items-center py-3 px-4 rounded-xl transition-all duration-300 hover:bg-white/20 hover:ring-2 hover:ring-green-400/50">
            <span class="mr-3 text-xl">📊</span>
            <span class="sidebar-text">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="penduduk.php" class="flex items-center py-3 px-4 rounded-xl transition-all duration-300 hover:bg-white/20 hover:ring-2 hover:ring-green-400/50">
            <span class="mr-3 text-xl">👨‍👩‍👧‍👦</span>
            <span class="sidebar-text">Data Penduduk</span>
          </a>
        </li>
        <li>
          <a href="berita_desa.php" class="flex items-center py-3 px-4 rounded-xl transition-all duration-300 hover:bg-white/20 hover:ring-2 hover:ring-green-400/50">
            <span class="mr-3 text-xl">📰</span>
            <span class="sidebar-text">Berita</span>
          </a>
        </li>
        <li>
          <a href="profil_desa.php" class="flex items-center py-3 px-4 rounded-xl transition-all duration-300 hover:bg-white/20 hover:ring-2 hover:ring-green-400/50">
            <span class="mr-3 text-xl">🏡</span>
            <span class="sidebar-text">Profil Desa</span>
          </a>
        </li>
        <li>
          <a href="logout.php" class="flex items-center py-3 px-4 rounded-xl bg-red-600/80 hover:bg-red-700 hover:ring-2 hover:ring-red-400/50 transition-all duration-300">
            <span class="mr-3 text-xl">🚪</span>
            <span class="sidebar-text">Logout</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>

  <!-- Tombol Toggle di Bawah -->
  <div class="flex justify-center mt-6">
    <button id="toggleSidebar" 
      class="bg-white/20 backdrop-blur-md border border-white/30 text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:bg-white/30 transition-all duration-300">
      <span id="toggleIcon">«</span>
    </button>
  </div>
</aside>

<!-- Script Toggle -->
<script>
  const sidebar = document.getElementById('sidebar');
  const toggleBtn = document.getElementById('toggleSidebar');
  const toggleIcon = document.getElementById('toggleIcon');

  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('w-64');   // lebar normal
    sidebar.classList.toggle('w-20');   // lebar kecil
    
    // toggle tulisan
    document.querySelectorAll('.sidebar-text').forEach(el => {
      el.classList.toggle('hidden');
    });

    // ganti icon tombol
    toggleIcon.textContent = sidebar.classList.contains('w-64') ? '«' : '»';
  });
</script>
