<?php

// Hitung jumlah penduduk
$q1 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk");
$total_penduduk = mysqli_fetch_assoc($q1)['total'];

// Hitung jumlah dusun
$q2 = mysqli_query($conn, "SELECT COUNT(DISTINCT dusun) AS total FROM t_penduduk");
$total_dusun = mysqli_fetch_assoc($q2)['total'];

// Hitung jumlah RW (unik per dusun)
$q3 = mysqli_query($conn, "SELECT COUNT(DISTINCT CONCAT(dusun,'-',rw)) AS total FROM t_penduduk");
$total_rw = mysqli_fetch_assoc($q3)['total'];

// Hitung jumlah RT (unik per dusun)
$q4 = mysqli_query($conn, "SELECT COUNT(DISTINCT CONCAT(dusun,'-',rw,'-',rt)) AS total FROM t_penduduk");
$total_rt = mysqli_fetch_assoc($q4)['total'];

// Hitung jumlah laki-laki
$q5 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk WHERE kelamin='L'");
$total_laki = mysqli_fetch_assoc($q5)['total'];

// Hitung jumlah perempuan
$q6 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM t_penduduk WHERE kelamin='P'");
$total_perempuan = mysqli_fetch_assoc($q6)['total'];

// Hitung jumlah keluarga (berdasarkan no_kk unik)
$q7 = mysqli_query($conn, "SELECT COUNT(DISTINCT no_kk) AS total FROM t_penduduk");
$total_keluarga = mysqli_fetch_assoc($q7)['total'];


?>

<section class="card">
    
    <!-- Card Statistik -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <!-- Jumlah Penduduk -->
        <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-green-600">
            <div class="bg-green-100 p-4 rounded-full">👨‍👩‍👧‍👦</div>
            <div>
                <h3 class="text-xl font-semibold text-gray-700">Jumlah Penduduk</h3>
                <p class="text-3xl font-bold text-green-700"><?= $total_penduduk; ?></p>
      </div>
    </div>
    
    <!-- Jumlah Dusun -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-blue-600">
        <div class="bg-blue-100 p-4 rounded-full">🏡</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Jumlah Dusun</h3>
            <p class="text-3xl font-bold text-blue-700"><?= $total_dusun; ?></p>
        </div>
    </div>
    
    <!-- Jumlah RW -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-purple-600">
        <div class="bg-purple-100 p-4 rounded-full">📌</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Jumlah RW</h3>
            <p class="text-3xl font-bold text-purple-700"><?= $total_rw; ?></p>
        </div>
    </div>

    <!-- Jumlah Keluarga -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-orange-600">
        <div class="bg-orange-100 p-4 rounded-full">👪</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Jumlah Keluarga</h3>
            <p class="text-3xl font-bold text-orange-700"><?= $total_keluarga; ?></p>
        </div>
    </div>

    
    <!-- Jumlah RT -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-yellow-600">
        <div class="bg-yellow-100 p-4 rounded-full">🛖</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Jumlah RT</h3>
            <p class="text-3xl font-bold text-yellow-700"><?= $total_rt; ?></p>
        </div>
    </div>
    
    <!-- Jumlah Laki-laki -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-indigo-600">
        <div class="bg-indigo-100 p-4 rounded-full">👨</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Laki-laki</h3>
            <p class="text-3xl font-bold text-indigo-700"><?= $total_laki; ?></p>
        </div>
    </div>
    
    <!-- Jumlah Perempuan -->
    <div class="bg-white shadow-lg rounded-lg p-6 flex items-center space-x-4 border-l-8 border-pink-600">
        <div class="bg-pink-100 p-4 rounded-full">👩</div>
        <div>
            <h3 class="text-xl font-semibold text-gray-700">Perempuan</h3>
            <p class="text-3xl font-bold text-pink-700"><?= $total_perempuan; ?></p>
        </div>
    </div>
</section>

