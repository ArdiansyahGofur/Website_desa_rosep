<?php

// Ambil data usia & jenis kelamin
$q = mysqli_query($conn, "
  SELECT 
    kelamin, 
    CASE 
      WHEN usia BETWEEN 0 AND 5 THEN '0-5'
      WHEN usia BETWEEN 6 AND 12 THEN '6-12'
      WHEN usia BETWEEN 13 AND 17 THEN '13-17'
      WHEN usia BETWEEN 18 AND 30 THEN '18-30'
      WHEN usia BETWEEN 31 AND 45 THEN '31-45'
      WHEN usia BETWEEN 46 AND 59 THEN '46-59'
      ELSE '60+' 
    END AS kategori_usia,
    COUNT(*) AS total
  FROM t_penduduk
  GROUP BY kategori_usia, kelamin
  ORDER BY kategori_usia
");

$data = [];
while ($row = mysqli_fetch_assoc($q)) {
    $data[$row['kategori_usia']][$row['kelamin']] = $row['total'];
}

// Format data untuk Chart.js
$usia_kategori = ["0-5","6-12","13-17","18-30","31-45","46-59","60+"];
$laki = [];
$perempuan = [];

foreach ($usia_kategori as $u) {
    $laki[] = isset($data[$u]['L']) ? $data[$u]['L'] : 0;
    $perempuan[] = isset($data[$u]['P']) ? $data[$u]['P'] : 0;
}


?>

    
<section class="diagram"> 
    <!-- Grafik Piramida Penduduk -->
    <div class="max-w-6xl mx-auto mt-12">
        <div class="bg-gradient-to-r from-green-50 to-green-100 shadow-2xl rounded-3xl p-8 hover:shadow-green-300 transition duration-500">
            <!-- Chart Container -->
            <div class="relative">
                <canvas id="piramidaChart" height="500"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctxPiramida = document.getElementById('piramidaChart').getContext('2d');

  new Chart(ctxPiramida, {
      type: 'bar',
      data: {
          labels: <?= json_encode($usia_kategori); ?>,
      datasets: [
          {
              label: 'Laki-laki',
              data: <?= json_encode(array_map(fn($v) => -$v, $laki)); ?>,
          backgroundColor: 'rgba(54, 162, 235, 0.8)',
          borderRadius: 6, // rounded bar
          borderSkipped: false
        },
        {
          label: 'Perempuan',
          data: <?= json_encode($perempuan); ?>,
          backgroundColor: 'rgba(255, 99, 132, 0.8)',
          borderRadius: 6, // rounded bar
          borderSkipped: false
        }
    ]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { 
            position: 'top',
            labels: {
                font: { size: 14 }
                }
            },
            title: {
                display: true,
                text: 'Piramida Penduduk Desa Rosep berdasarkan Usia & Jenis Kelamin',
                font: { size: 18, weight: 'bold' }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let value = context.raw;
                return (value < 0 ? -value : value) + ' orang';
                }
            }
            }
        },
        animation: {
            duration: 1500,
            easing: 'easeOutBounce'
        },
        scales: {
            x: {
                stacked: true,
                title: { display: true, text: 'Jumlah Penduduk', font: { size: 14 } },
                ticks: {
                    callback: function(value) {
                        return Math.abs(value);
                    }
                }
            },
            y: {
                stacked: true,
                title: { display: true, text: 'Kelompok Usia', font: { size: 14 } }
            }
        }
        }
    });
    </script>
</section>