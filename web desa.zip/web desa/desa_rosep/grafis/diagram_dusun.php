<?php

// Ambil data jumlah penduduk per dusun
$q_dusun = mysqli_query($conn, "
  SELECT dusun, COUNT(*) as total 
  FROM t_penduduk 
  GROUP BY dusun
");

$dusun = [];
$total_dusun_chart = [];
while ($row = mysqli_fetch_assoc($q_dusun)) {
  $dusun[] = $row['dusun'];
  $total_dusun_chart[] = $row['total'];
}

?>

<section class="diagram dusun max-w-4xl mx-auto mt-12 px-4">
  <div class="bg-white rounded-2xl p-6 border border-gray-200">
    
    <!-- Judul -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
      <span class="text-3xl">🏘️</span> 
      Penduduk per Dusun
    </h2>
    <p class="text-gray-500 mb-6 text-sm">Distribusi jumlah penduduk berdasarkan dusun</p>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      <!-- Diagram Lingkaran Modern -->
      <div class="relative h-64">
        <canvas id="dusunChart"></canvas>
      </div>

      <!-- Tabel Minimalis -->
      <div class="overflow-hidden rounded-xl border border-gray-100">
        <table class="min-w-full text-sm text-gray-700">
          <thead class="bg-gray-100 text-gray-600">
            <tr>
              <th class="px-3 py-2 text-left">Dusun</th>
              <th class="px-3 py-2 text-right">Jumlah</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($dusun as $i => $d): ?>
              <tr class="hover:bg-gray-50 transition">
                <td class="px-3 py-2"><?= $d; ?></td>
                <td class="px-3 py-2 text-right font-medium text-gray-800"><?= $total_dusun_chart[$i]; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
  <script>
    const ctxDusun = document.getElementById('dusunChart').getContext('2d');

    new Chart(ctxDusun, {
      type: 'doughnut',
      data: {
        labels: <?= json_encode($dusun); ?>,
        datasets: [{
          data: <?= json_encode($total_dusun_chart); ?>,
          backgroundColor: [
            '#60A5FA', '#F87171', '#FBBF24', '#34D399', '#A78BFA', '#FDBA74'
          ],
          borderWidth: 0,
          cutout: '60%'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { size: 12 },
              color: '#4B5563'
            }
          },
          tooltip: {
            backgroundColor: '#111827',
            titleColor: '#F9FAFB',
            bodyColor: '#F9FAFB',
            bodyFont: { size: 12 },
            callbacks: {
              label: function(context) {
                return context.label + ': ' + context.raw;
              }
            }
          },
          datalabels: {
            color: '#fff',
            font: { size: 12, weight: '500' },
            formatter: function(value) { return value; }
          }
        },
        animation: {
          animateRotate: true,
          animateScale: true,
          duration: 1200,
          easing: 'easeOutCubic'
        }
      },
      plugins: [ChartDataLabels]
    });
  </script>
</section>