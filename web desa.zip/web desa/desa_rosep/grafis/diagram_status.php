<?php

// Query PHP untuk data status
$sql = "SELECT status, COUNT(*) AS jumlah
        FROM t_penduduk
        GROUP BY status
        ORDER BY jumlah DESC";

$result = $conn->query($sql);

$status = [];
$total_status_chart = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $status[] = $row['status'];
        $total_status_chart[] = (int)$row['jumlah'];
    }
}

// Array ikon sesuai status (bisa diganti dengan path gambar atau emoji)
$status_icons = [
    'Menikah' => '💍',
    'Belum Menikah' => '👤',
    'Duda' => '👨',
    'Janda' => '👩',
    'Lainnya' => '❓'
];

?>

<section class="status max-w-6xl mx-auto mt-12 px-4">
  <div class="bg-white rounded-2xl p-6 border border-gray-200">

    <!-- Judul -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
      <span class="text-3xl">📊</span> 
      Distribusi Status Penduduk
    </h2>
    <p class="text-gray-500 mb-6 text-sm">Jumlah penduduk berdasarkan status, dengan ikon visual</p>

    <!-- Cards per Status -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <?php foreach ($status as $i => $s): ?>
        <div class="bg-indigo-50 rounded-xl p-4 flex flex-col items-center justify-center shadow hover:shadow-indigo-200 transition">
          <!-- Icon -->
          <div class="text-4xl mb-2">
            <?= isset($status_icons[$s]) ? $status_icons[$s] : '❓'; ?>
          </div>
          <!-- Nama Status -->
          <h3 class="text-lg font-semibold text-indigo-800"><?= $s; ?></h3>
          <!-- Jumlah -->
          <p class="text-gray-700 mt-1 font-medium"><?= $total_status_chart[$i]; ?> orang</p>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>