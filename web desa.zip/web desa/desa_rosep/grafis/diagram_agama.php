<?php

// Query PHP untuk data agama
$sql = "SELECT agama, COUNT(*) AS jumlah
        FROM t_penduduk
        GROUP BY agama
        ORDER BY jumlah DESC";

$result = $conn->query($sql);

$agama = [];
$total_agama_chart = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $agama[] = $row['agama'];
        $total_agama_chart[] = (int)$row['jumlah'];
    }
}

// Array ikon sesuai agama (emoji atau bisa diganti dengan path gambar)
$agama_icons = [
    'Islam' => '🕌',
    'Kristen' => '⛪',
    'Katolik' => '✝️',
    'Hindu' => '🛕',
    'Buddha' => '🕉️',
    'Konghucu' => '☯️',
    'Lainnya' => '❓'
];

?>

<section class="agama max-w-6xl mx-auto mt-12 px-4">
  <div class="bg-white rounded-2xl p-6 border border-gray-200">

    <!-- Judul -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
      <span class="text-3xl">🙏</span> 
      Distribusi Penduduk Berdasarkan Agama
    </h2>
    <p class="text-gray-500 mb-6 text-sm">Jumlah penduduk berdasarkan agama dengan ikon visual</p>

    <!-- Cards per Agama -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <?php foreach ($agama as $i => $a): ?>
        <div class="bg-green-50 rounded-xl p-4 flex flex-col items-center justify-center shadow hover:shadow-green-200 transition">
          <!-- Icon -->
          <div class="text-4xl mb-2">
            <?= isset($agama_icons[$a]) ? $agama_icons[$a] : '❓'; ?>
          </div>
          <!-- Nama Agama -->
          <h3 class="text-lg font-semibold text-green-800"><?= $a; ?></h3>
          <!-- Jumlah -->
          <p class="text-gray-700 mt-1 font-medium"><?= $total_agama_chart[$i]; ?> orang</p>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>