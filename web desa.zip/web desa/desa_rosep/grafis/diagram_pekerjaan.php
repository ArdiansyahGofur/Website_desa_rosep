<?php

// Contoh query PHP/MySQL untuk data pekerjaan
$sql = "SELECT pekerjaan, COUNT(*) AS jumlah 
        FROM t_penduduk
        GROUP BY pekerjaan
        ORDER BY jumlah DESC"; // urut dari yang terbanyak

$result = $conn->query($sql);

$pekerjaan = [];
$total_pekerjaan_chart = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $pekerjaan[] = $row['pekerjaan'];
        $total_pekerjaan_chart[] = (int)$row['jumlah'];
    }
}

?>

<section class="pekerjaan max-w-6xl mx-auto mt-12 px-4">
  <div class="bg-white rounded-2xl p-6 border border-gray-200">
    
    <!-- Judul -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
      <span class="text-3xl">💼</span> 
      Distribusi Pekerjaan Penduduk
    </h2>
    <p class="text-gray-500 mb-6 text-sm">Jumlah penduduk berdasarkan pekerjaan, diurutkan dari yang terbanyak</p>

    <!-- Tabel Scrollable -->
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm text-gray-700 border border-gray-100 rounded-xl">
        <thead class="bg-indigo-50 text-gray-800">
          <tr>
            <th class="px-4 py-2 text-left">Pekerjaan</th>
            <th class="px-4 py-2 text-right">Jumlah Penduduk</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pekerjaan as $i => $p): ?>
            <tr class="border-t border-gray-100 hover:bg-indigo-50 transition">
              <td class="px-4 py-2"><?= $p; ?></td>
              <td class="px-4 py-2 text-right font-medium text-gray-800"><?= $total_pekerjaan_chart[$i]; ?> orang</td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Card per Pekerjaan -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
      <?php foreach ($pekerjaan as $i => $p): ?>
        <div class="bg-indigo-50 rounded-xl p-4 flex flex-col items-center justify-center shadow hover:shadow-indigo-200 transition">
          <h3 class="text-lg font-semibold text-indigo-800"><?= $p; ?></h3>
          <p class="text-gray-700 mt-1 font-medium"><?= $total_pekerjaan_chart[$i]; ?> orang</p>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>
