<?php

// Ambil data jumlah penduduk per tingkat pendidikan
$sql = "SELECT pendidikan, COUNT(*) AS jumlah 
        FROM t_penduduk
        GROUP BY pendidikan
        ORDER BY pendidikan ASC"; // bisa diubah sesuai urutan yang diinginkan

$result = $conn->query($sql);

$pendidikan = [];
$total_pendidikan_chart = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $pendidikan[] = $row['pendidikan'];
        $total_pendidikan_chart[] = (int)$row['jumlah'];
    }
}

?>

<section class="pendidikan max-w-4xl mx-auto mt-12 px-4">
  <div class="bg-white rounded-2xl p-6 border border-gray-200">
    
    <!-- Judul -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
      <span class="text-3xl">📊</span> 
      Distribusi Pendidikan Penduduk
    </h2>
    <p class="text-gray-500 mb-6 text-sm">Jumlah penduduk berdasarkan tingkat pendidikan</p>

    <div class="relative h-64">
      <canvas id="pendidikanChartBar"></canvas>
    </div>

    

  </div>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
  <script>
    const ctxPendidikanBar = document.getElementById('pendidikanChartBar').getContext('2d');

    new Chart(ctxPendidikanBar, {
      type: 'bar',
      data: {
        labels: <?= json_encode($pendidikan); ?>,
        datasets: [{
          label: 'Jumlah Penduduk',
          data: <?= json_encode($total_pendidikan_chart); ?>,
          backgroundColor: '#60A5FA',
          borderRadius: 6, // membuat batang lebih modern dengan sudut membulat
          barPercentage: 0.6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: '#111827',
            titleColor: '#F9FAFB',
            bodyColor: '#F9FAFB',
            bodyFont: { size: 12 },
            callbacks: {
              label: function(context) {
                return context.dataset.label + ': ' + context.raw;
              }
            }
          },
          datalabels: {
            anchor: 'end',
            align: 'end',
            color: '#111827',
            font: { weight: '500', size: 12 },
            formatter: function(value) { return value; }
          }
        },
        scales: {
          x: {
            ticks: { color: '#4B5563', font: { size: 12 } },
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            ticks: { color: '#4B5563', font: { size: 12 } },
            grid: { color: '#E5E7EB', borderDash: [4, 4] }
          }
        },
        animation: {
          duration: 1200,
          easing: 'easeOutCubic'
        }
      },
      plugins: [ChartDataLabels]
    });
  </script>
</section>